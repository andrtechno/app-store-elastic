<?php

use panix\engine\Html;

echo Html::a('dates', ['dates'], ['class' => 'btn btn-default']);
echo Html::a('view', ['view'], ['class' => 'btn btn-default']);





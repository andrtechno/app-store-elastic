<?php

use panix\engine\Html;

echo Html::a('check', ['check'], ['class' => 'btn btn-default']);
echo Html::a('info', ['info'], ['class' => 'btn btn-default']);
echo Html::a('zones', ['zones'], ['class' => 'btn btn-default']);



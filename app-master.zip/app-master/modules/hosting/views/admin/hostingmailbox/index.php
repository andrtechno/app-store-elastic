<?php

use panix\engine\Html;

echo Html::a('info', ['info'], ['class' => 'btn btn-default']);
echo Html::a('Create', ['create'], ['class' => 'btn btn-default']);





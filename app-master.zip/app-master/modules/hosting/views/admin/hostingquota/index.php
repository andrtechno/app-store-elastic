<?php

use panix\engine\Html;

echo Html::a('info', ['info'], ['class' => 'btn btn-default']);
echo Html::a('used_ftp', ['used-ftp'], ['class' => 'btn btn-default']);
echo Html::a('used_mysql', ['used-mysql'], ['class' => 'btn btn-default']);



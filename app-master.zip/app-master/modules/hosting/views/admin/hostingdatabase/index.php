<?php

use panix\engine\Html;

echo Html::a('info', ['info'], ['class' => 'btn btn-default']);
echo Html::a('DatabaseCreate', ['database-create'], ['class' => 'btn btn-default']);
echo Html::a('user_privileges', ['user-privileges'], ['class' => 'btn btn-default']);




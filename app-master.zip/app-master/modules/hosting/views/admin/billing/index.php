<?php

use panix\engine\Html;


echo Html::a('info', ['info'], ['class' => 'btn btn-default']);
echo Html::a('pay', ['pay'], ['class' => 'btn btn-default']);




<?php

use panix\engine\Html;


echo Html::a('info', ['info'], ['class' => 'btn btn-default']);
echo Html::a('plans', ['plans'], ['class' => 'btn btn-default']);




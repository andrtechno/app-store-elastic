<?php

return [
    'PASSWORD' => 'Пароль базы данных',
];

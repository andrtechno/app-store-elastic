<?php

return [
    'CREATE_PRODUCT' => 'Добавить товар',
    'CREATE_MANUFACTURER' => 'Добавить производителя',
    'CREATE_CURRENCY' => 'Добавить валюту',
    'CURRENCY' => 'Валюта',
    'CATEGORIES' => 'Категории',
    'TYPE_PRODUCTS' => 'Тип товаров',
    'ATTRIBUTES' => 'Атрибуры',
    'PRODUCTS' => 'Продукция',
    'MANUFACTURER' => 'Производители',
    'CATEGORY_TREE_CREATE' => 'Категория успешно добавлена.',
    'CATEGORY_TREE_RENAME' => 'Категория успешно переименована.',
    'CATEGORY_TREE_SWITCH_ON' => 'Категория успешно скрыта',
    'CATEGORY_TREE_SWITCH_OFF' => 'Категория успешно показана',
    'FIEND_REQUIRED' => 'Поле {field} обязательно для заполнения',
];


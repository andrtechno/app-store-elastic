<?php

return [
    'NAME' => 'Название товара',
    'SLUG' => 'URL-адрес',
    'IMAGE' => 'Изображение',
    'DATE_CREATE' => 'Дата создания',
    'DATE_UPDATE' => 'Дата обновления',
    'SKU' => 'Артикул',
    'PRICE' => 'Цена',
    'TEXT' => 'Описание товара',
    'MANUFACTURER_ID' => 'Производитель',
    'CATEGORY_ID' => 'Категория',
    'VIEWS' => 'Просмотры',
    'ADDED_TO_CART_COUNT' => 'Добавление в корзину',
    'FULL_DESCRIPTION' => 'Описание',
    'TAB_MAIN' => 'Основное',
];


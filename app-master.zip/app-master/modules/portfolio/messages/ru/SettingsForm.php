<?php

return [
    'PER_PAGE'=>'cnh',
    'PRICE_PENNY'=>'Активировать копейки',
    'PRICE_DECIMAL' => 'Десятичный разделитель цены',
    'PRICE_THOUSAND' => 'Тысячный разделитель цены',

];
?>
